<?php
require 'db_connection.php';

echo "✅ Database connected successfully!";
?>
